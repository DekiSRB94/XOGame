<!DOCTYPE html>
<html>
<head>
  <title>X O game</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<style>
table, th, td {
  border: 3px solid #0F2027;
  border-collapse: collapse;
}
th, td {
  padding: 5px;
  text-align: left;
}

body{
	color: #7FCDCD;
	background-color: black;
}

@media  screen and (max-width: 650px){
    .game_table{
    	margin-left: 15% !important;
    }
    .menu{
    	margin-top: 80% !important;
    	margin-left: 30% !important;
    }
}

footer {
  		flex-shrink: 0;
      color: red;
      padding: 10px;
      font-size: 20px;
      background: #0F2027;  /* fallback for old browsers */
      background: -webkit-linear-gradient(to left, #2C5364, #203A43, #0F2027);  /* Chrome 10-25, Safari 5.1-6 */
      background: linear-gradient(to left, #2C5364, #203A43, #0F2027); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
}
#author{
      color: #FFD700;
      font-style: italic;
      font-weight: bold;
}


input[type="text"], textarea {
  color: lightblue;
  background-color: #0F2027; 
}

body{ overflow-x: hidden;}

</style>


<body>
	<!-- menu for chossing singleplayer or multiplayer mod  -->
	<div style="width:250px;height:200px; margin-left:45%; margin-top:20%;" class="menu">
	<button class="singplayer_button" type="button" style="width:150px; background: #0F2027; color:lightblue; border:2px solid black;">Single player</button>
	<br>
	<button class="multiplayer_button" style="width:150px; background: #0F2027; color:lightblue; border:2px solid black; margin-top:10px;">Multiplayer</button>
	</div>

<!-- multiplayer mod -->
<div style="display:none;" class="multiplayer">
<center><h2>X O</h2></center>
<center><p>game</p></center>
<br><br>


<div class="post_battle">
<form class="form" method="POST" action="/battle" onsubmit="postBattleHistory(); return false;">

<?php echo csrf_field(); ?>

<br>
<p style="float:left; margin-left:20%;">X:</p><input style="float:left;" type="text" class="x" name="player_x" placeholder="enter name">
<br><br>
<p style="float:left; margin-left:20%;">O:</p><input style="float:left;" type="text" class="o" name="player_o"  placeholder="enter name and click" readonly="true">
<br><br>
<input class="time" style="margin-left:21%;" type="hidden" name="battle_time">
<input style="margin-left:21%;" class="winner_for_submit" type="hidden" name="winner">
</form>
</div>

<br>
<div class="row">
<div class="col-lg-12">
<p class="who_start_game" style="float:left; margin-left:21%; font-weight:bold;"></p>
<p class="hidden_text" style="float:left; margin-left:3px; font-weight:bold; display:none;">start first !</p>
</div>
</div>

<br>
<button class="revenge_button" onclick="revenge();" style="margin-left:21%; background-color: lightblue; color: black; border: 3px solid black; display:none;" type="submit">Revenge</button>

<div class="row">
<div class="col-lg-6">
<div style="margin-top:100px; margin-left:35%; display:none;" class="game_table">
<div class="row">
<div class="col col-lg-12">
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left;" class="square_1" onclick="clickFunction1()"><img class="img1" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_2" onclick="clickFunction2()"><img class="img2" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_3" onclick="clickFunction3()"><img class="img3" src=""></div>
</div>

<div style="margin-top:2px;" class="col-lg-12">
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left;" class="square_4" onclick="clickFunction4()"><img class="img4" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_5" onclick="clickFunction5()"><img class="img5" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_6" onclick="clickFunction6()"><img class="img6" src=""></div>
</div>

<div style="margin-top:2px;" class="col-lg-12">
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left;" class="square_7" onclick="clickFunction7()"><img class="img7" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_8" onclick="clickFunction8()"><img class="img8" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_9" onclick="clickFunction9()"><img class="img9" src=""></div>
</div>
</div>
		<br>
		<h3 style="display:none;" class="winner">Winner</h3>
		<p style="font-size:20px; color:green;" class="who"></p>
		<p style="display:none; font-size:20px; color:red;" class="draw">Game is draw !</p>
		<p class="timer" name="timer"></p>
</div>
</div>

<div class="col-lg-6">
<div style="margin-top:100px; margin-left:15%;" class="battle_history">
<table style="width:40vh;">
  <tr>
    <th>Player X</th>
    <th>Player O</th>
  </tr>
  	<?php $__currentLoopData = $battle_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b_h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  	<tr>
  		<?php if($b_h->winner == $b_h->player_x): ?>
	    	<td style="color:green;"><?php echo e($b_h->player_x); ?></td>
	    <?php endif; ?>
	    <?php if($b_h->winner != $b_h->player_x && $b_h->winner == $b_h->player_o): ?>
	    	<td style="color:red;"><?php echo e($b_h->player_x); ?></td>
	    <?php endif; ?>
	    <?php if($b_h->winner == $b_h->player_o): ?>
	    	<td style="color:green;"><?php echo e($b_h->player_o); ?></td>
	    <?php endif; ?>
	    <?php if($b_h->winner != $b_h->player_o && $b_h->winner == $b_h->player_x): ?>
	    	<td style="color:red;"><?php echo e($b_h->player_o); ?></td>
	    <?php endif; ?>
	    <?php if($b_h->winner == "Draw game"): ?>
	    	<td style="color:orange;"><?php echo e($b_h->player_x); ?></td>
	    	<td style="color:orange;"><?php echo e($b_h->player_o); ?></td>
	    <?php endif; ?>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</div>
</div>
</div>





<!-- singleplayer mod -->
<div style="display:none;" class="singleplayer">
<center><h2>X O</h2></center>
<center><p>game</p></center>
<br><br>


<div class="post_battle">
<form class="singleplayer_form" method="POST" action="/singleplayer_battle" onsubmit="postSingleplayerBattleHistory(); return false;">

<?php echo csrf_field(); ?>

<br>
<p style="float:left; margin-left:20%;">X:</p><input style="float:left;" type="text" class="player" name="player_x" placeholder="enter name">
<br><br>
<p style="float:left; margin-left:20%;">O:</p><input style="float:left;" type="text" class="cpu" name="player_o"  
value="CPU" readonly="true">
<br><br>
<input class="time" style="margin-left:21%;" type="hidden" name="battle_time">
<input style="margin-left:21%;" class="winner_for_submit" type="hidden" name="winner">
</form>
</div>

<br>
<div class="row">
<div class="col-lg-12">
<p class="who_start_game" style="float:left; margin-left:21%; font-weight:bold;"></p>
<p class="hidden_text" style="float:left; margin-left:3px; font-weight:bold; display:none;">start first !</p>
</div>
</div>

<br>
<button class="revenge_button_singleplayer" onclick="revengeSingleplayer();" style="margin-left:21%; background-color: lightblue; color: black; border: 3px solid black; display:none;" type="submit">Revenge</button>

<div class="row">
<div class="col-lg-6">
<div style="margin-top:100px; margin-left:35%; display:none;" class="game_table_single">
<div class="row">
<div class="col col-lg-12">
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left;" class="square_1s" onclick="clickFunction1s()"><img class="img1" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_2s" onclick="clickFunction2s()"><img class="img2" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_3s" onclick="clickFunction3s()"><img class="img3" src=""></div>
</div>

<div style="margin-top:2px;" class="col-lg-12">
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left;" class="square_4s" onclick="clickFunction4s()"><img class="img4" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_5s" onclick="clickFunction5s()"><img class="img5" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_6s" onclick="clickFunction6s()"><img class="img6" src=""></div>
</div>

<div style="margin-top:2px;" class="col-lg-12">
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left;" class="square_7s" onclick="clickFunction7s()"><img class="img7" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_8s" onclick="clickFunction8s()"><img class="img8" src=""></div>
<div style="width:12vh;height:12vh;border:3px solid #0F2027; float:left; margin-left:2px;" class="square_9s" onclick="clickFunction9s()"><img class="img9" src=""></div>
</div>
</div>
		<br>
		<h3 style="display:none;" class="winner">Winner</h3>
		<p style="font-size:20px; color:green;" class="who"></p>
		<p style="display:none; font-size:20px; color:red;" class="draw">Game is draw !</p>
		<p class="timer" name="timer"></p>
		<p class="n"></p>
</div>
</div>

<div class="col-lg-6">
<div style="margin-top:100px; margin-left:15%;" class="battle_history_singleplayer">
<table style="width:40vh;">
  <tr>
    <th>Player X</th>
    <th>Player O</th>
  </tr>
  	<?php $__currentLoopData = $battle_history_singleplayer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b_h_s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  	<tr>
  		<?php if($b_h_s->winner == $b_h_s->player_x): ?>
	    	<td style="color:green;"><?php echo e($b_h_s->player_x); ?></td>
	    <?php endif; ?>
	    <?php if($b_h_s->winner != $b_h_s->player_x && $b_h_s->winner == $b_h_s->player_o): ?>
	    	<td style="color:red;"><?php echo e($b_h_s->player_x); ?></td>
	    <?php endif; ?>
	    <?php if($b_h_s->winner == $b_h_s->player_o): ?>
	    	<td style="color:green;"><?php echo e($b_h_s->player_o); ?></td>
	    <?php endif; ?>
	    <?php if($b_h_s->winner != $b_h_s->player_o && $b_h_s->winner == $b_h_s->player_x): ?>
	    	<td style="color:red;"><?php echo e($b_h_s->player_o); ?></td>
	    <?php endif; ?>
	    <?php if($b_h_s->winner == "Draw game"): ?>
	    	<td style="color:orange;"><?php echo e($b_h_s->player_x); ?></td>
	    	<td style="color:orange;"><?php echo e($b_h_s->player_o); ?></td>
	    <?php endif; ?>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</div>

</div>
</div>



<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer>
  <center><p>Design by:</p> <p id="author">Dekster</p></center>
</footer>


<!-- for multiplayer -->
<script>
// display multiplayer mod
$(".multiplayer_button").on('click', function(){
   $('.multiplayer').css('display', 'block');
   $('.menu').css('display', 'none');
});


//ajax function for posing informations(winner,time)
function postBattleHistory(){
  $('.form').each(function(){
    var formdata = $(this).serialize();
      $.ajax($(this).attr('action'),
        {
        method: $(this).attr('method'),
        data: formdata
        })
        });
}

//ajax function for refreshing battle history to see last battle
function refreshBattleHistory(){
  $.get('/x-o-game', function(data){ 
      $('.battle_history').empty().append( $(data).find('.battle_history').children() );
  });
}


//checking if input x is empty, after that checking if input o is empty, end if they not game table show
//and game choose who start first
$(document).ready(function(){
	$('.x').blur(function(){
        if(!$(this).val()){
            $(this).addClass("alert-danger");
        } else{
        	$(".o").prop("readonly", false);
            $(this).removeClass("alert-danger");
            $(".x").prop( "readonly", true);
        }
    });
    $('.o').blur(function(){
        if(!$(this).val()){
            $(this).addClass("alert-danger");
        } else{
        	$(".game_table").css("display", "block");
            $(this).removeClass("alert-danger");
            $(".o").prop("readonly", true);
            $(".hidden_text").css("display", "block");
            whoStartFirst();
        }
    });
});

//function for checking if numbers exist in array
function isTrue(arr, arr2){
  return arr.every(i => arr2.includes(i));
}

//count for number of turns
var n = 0;
//function for checking if game is draw
function isDraw(){
	if(n == 9){
	  if((!isTrue(win1, player_1_fields))&&(!isTrue(win2, player_1_fields))&&(!isTrue(win3, player_1_fields))&&(!isTrue(win4, player_1_fields))&&(!isTrue(win5, player_1_fields))&&(!isTrue(win6, player_1_fields))&&(!isTrue(win7, player_1_fields))&&(!isTrue(win8, player_1_fields))&&(!isTrue(win1, player_2_fields))&&(!isTrue(win2, player_2_fields))&&(!isTrue(win3, player_2_fields))&&(!isTrue(win4, player_2_fields))&&(!isTrue(win5, player_2_fields))&&(!isTrue(win6, player_2_fields))&&(!isTrue(win7, player_2_fields))&&(!isTrue(win8, player_2_fields))){
	      stopTimer();
	      $(".draw").css("display", "inline");
	      $(".winner_for_submit").val("Draw game");
	      $(".form").submit();
	      refreshBattleHistory();
	      $(".revenge_button").css("display", "inline");
	  }
	}
}

//function for checking win for player X 
function isWinX(){
	if((isTrue(win1, player_1_fields))||(isTrue(win2, player_1_fields))||(isTrue(win3, player_1_fields))||(isTrue(win4, player_1_fields))||(isTrue(win5, player_1_fields))||(isTrue(win6, player_1_fields))||(isTrue(win7, player_1_fields))||(isTrue(win8, player_1_fields))){
	     setTimeout(function(){
			$(".winner").css("display", "inline");
			var x = $(".x").val();
			$(".who").html(x);
			$(".winner_for_submit").val(x);
			$(".form").submit();
			refreshBattleHistory();
			$(".revenge_button").css("display", "inline");
		 }, 10);
		for(var i=0; i<=9; i++){
			$(".square_" + i).attr("onclick", "false");
		}
		stopTimer();
	}
}

//function for checking win for player O
function isWinO(){
	if((isTrue(win1, player_2_fields))||(isTrue(win2, player_2_fields))||(isTrue(win3, player_2_fields))||(isTrue(win4, player_2_fields))||(isTrue(win5, player_2_fields))||(isTrue(win6, player_2_fields))||(isTrue(win7, player_2_fields))||(isTrue(win8, player_2_fields))){
	        setTimeout(function(){
			    $(".winner").css("display", "inline");
			    var o = $(".o").val();
			    $(".who").html(o);
			    $(".winner_for_submit").val(o);
				$(".form").submit();
				refreshBattleHistory();
				$(".revenge_button").css("display", "inline");
			}, 10);
			for(var i=0; i<=9; i++){
				$(".square_" + i).attr("onclick", "false");
			}
			stopTimer();
	     }
}

function revenge(){
	$.get('/x-o-game', function(data){ 
      $('.game_table').empty().append( $(data).find('.game_table').children() );
  	});
  	turn = "";
	n = 0;
	player_1_fields = [];
	player_2_fields = [];
	$('.who_start_game').html("");
	whoPlayNext();
	$('.time').html("");
	$('.timer').html("");
		$('.game_table').one('click',function(){
		timer_for_new_game();
		});
	$(".revenge_button").css("display", "none");
}


/*
1 2 3
4 5 6
7 8 9
*/
//winner combinations in arrays
var win1 = [1,2,3];
var win2 = [4,5,6];
var win3 = [7,8,9];
var win4 = [1,4,7];
var win5 = [2,5,8];
var win6 = [3,6,9];
var win7 = [1,5,9];
var win8 = [3,5,7];

//which player click which field(if player 1 click field 1, field 1 will be added in player 1 array)
var player_1_fields = [];
var player_2_fields = [];

//x and o pictures for player x and player 0
var player_1_pic = "img/x_pic.png";
var player_2_pic = "img/o_pic.png";

//with turn helper we know who play next
var turn_helper;
var turn;
//function that random chosse which player play first
function whoStartFirst(){
	var random_value = Math.floor((Math.random() * 2) + 1);
	if(random_value == 1){
		turn = player_1_pic;
		turn_helper = player_1_pic;
		$('.who_start_game').html("Player X");
	}
	else{
		turn = player_2_pic;
		turn_helper = player_2_pic;
		$('.who_start_game').html("Player O");
	}
}

//function for chossing who play next, every game other player play first
function whoPlayNext(){
	if(turn_helper == player_1_pic){
		turn = player_2_pic;
		turn_helper = player_2_pic;
		$('.who_start_game').html("Player O");
	}
	else{
		turn = player_1_pic;
		turn_helper = player_1_pic;
		$('.who_start_game').html("Player X");
	}
}

//9 fields, 9 click functions
function clickFunction1() {
if(turn == player_1_pic){
	n++;
	  $(".img1").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_1").attr("onclick", "false");
	  player_1_fields.push(1);
		    isWinX();
	        isDraw();
} 
else{
	  n++;
	  $(".img1").attr("src", player_2_pic).fadeIn('fast').css('width', '11vh');	
	  turn = player_1_pic;
	  $(".square_1").attr("onclick", "false");
	  player_2_fields.push(1);
	  	 isWinO();
	     isDraw();
}
}
function clickFunction2() {
if(turn == player_1_pic){
	n++;
	  $(".img2").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_2").attr("onclick", "false");
	  player_1_fields.push(2);
	        isWinX();
	        isDraw();
} 
else{
	n++;
	  $(".img2").attr("src", player_2_pic).fadeIn('fast').css('width', '11vh');	
	  turn = player_1_pic;
	  $(".square_2").attr("onclick", "false");
	  player_2_fields.push(2);
	  		isWinO();
	        isDraw();
}
}

function clickFunction3() {
if(turn == player_1_pic){
	n++;
	  $(".img3").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_3").attr("onclick", "false");
	  player_1_fields.push(3);
	        isWinX();
	        isDraw();
} 
else{
	n++;
	  $(".img3").attr("src", player_2_pic).fadeIn('fast').css('width', '11vh');	
	  turn = player_1_pic;
	  $(".square_3").attr("onclick", "false");
	  player_2_fields.push(3);
	  		isWinO();
	        isDraw();
}
}

function clickFunction4() {
if(turn == player_1_pic){
	n++;
	  $(".img4").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_4").attr("onclick", "false");
	  player_1_fields.push(4);
	        isWinX();
	        isDraw();
} 
else{
	n++;
	  $(".img4").attr("src", player_2_pic).fadeIn('fast').css('width', '11vh');	
	  turn = player_1_pic;
	  $(".square_4").attr("onclick", "false");
	  player_2_fields.push(4);
	  		isWinO();
	        isDraw();
}
}

function clickFunction5() {
if(turn == player_1_pic){
	n++;
	  $(".img5").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_5").attr("onclick", "false");
	  player_1_fields.push(5);
	        isWinX();
	        isDraw();
} 
else{
	n++;
	  $(".img5").attr("src", player_2_pic).fadeIn('fast').css('width', '11vh');	
	  turn = player_1_pic;
	  $(".square_5").attr("onclick", "false");
	  player_2_fields.push(5);
	  		isWinO();
	        isDraw();
}
}

function clickFunction6() {
if(turn == player_1_pic){
	n++;
	  $(".img6").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_6").attr("onclick", "false");
	  player_1_fields.push(6);
	        isWinX();
	        isDraw();
} 
else{
	n++;
	  $(".img6").attr("src", player_2_pic).fadeIn('fast').css('width', '11vh');	
	  turn = player_1_pic;
	  $(".square_6").attr("onclick", "false");
	  player_2_fields.push(6);
	  		isWinO();
	        isDraw();
}
}

function clickFunction7() {
if(turn == player_1_pic){
	n++;
	  $(".img7").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_7").attr("onclick", "false");
	  player_1_fields.push(7);
	        isWinX();
	        isDraw();
} 
else{
	n++;
	  $(".img7").attr("src", player_2_pic).fadeIn('fast').css('width', '11vh');	
	  turn = player_1_pic;
	  $(".square_7").attr("onclick", "false");
	  player_2_fields.push(7);
	  		isWinO();
	        isDraw();
}
}

function clickFunction8() {
if(turn == player_1_pic){
	n++;
	  $(".img8").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_8").attr("onclick", "false");
	  player_1_fields.push(8);
	        isWinX();
	        isDraw();
} 
else{
	n++;
	  $(".img8").attr("src", player_2_pic).fadeIn('fast').css('width', '11vh');	
	  turn = player_1_pic;
	  $(".square_8").attr("onclick", "false");
	  player_2_fields.push(8);
	  		isWinO();
	        isDraw();
}
}

function clickFunction9() {
if(turn == player_1_pic){
	n++;
	  $(".img9").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_9").attr("onclick", "false");
	  player_1_fields.push(9);
	        isWinX();
	        isDraw();
} 
else{
	n++;
	  $(".img9").attr("src", player_2_pic).fadeIn('fast').css('width', '11vh');	
	  turn = player_1_pic;
	  $(".square_9").attr("onclick", "false");
	  player_2_fields.push(9);
	  		isWinO();
	        isDraw();
}
}

//timer, start and stop for timer
var interval;
function timer_for_new_game(){
var timer3 = "0:00";
interval = setInterval(function() {
  var timer2 = timer3.split(':');
  //by parsing integer, I avoid all extra string processing
  var minutes = parseInt(timer2[0], 10);
  var seconds = parseInt(timer2[1], 10);
  ++seconds;
  minutes = (seconds > 59) ? ++minutes : minutes;
  seconds = (seconds > 59) ? 00 : seconds;
  $('.timer').html(minutes + ':' + seconds);
  $('.time').val(minutes + ':' + seconds);
  timer3 = minutes + ':' + seconds;
}, 1000) };

function stopTimer() {
  clearInterval(interval);
}

//on click on table timer start
$('.game_table').one('click',function(){
	timer_for_new_game();
});

</script>








<!-- for singleplayer -->
<script>
// display singleplayer mod
$(".singplayer_button").on('click', function(){
   $('.singleplayer').css('display', 'block');
   $('.menu').css('display', 'none');
});

//ajax function for posing informations(winner,time)
function postSingleplayerBattleHistory(){
  $('.singleplayer_form').each(function(){
    var formdata = $(this).serialize();
      $.ajax($(this).attr('action'),
        {
        method: $(this).attr('method'),
        data: formdata
        })
        });
}

//ajax function for refreshing battle history to see last battle
function refreshBattleHistorySingleplayer(){
  $.get('/x-o-game', function(data){ 
      $('.battle_history_singleplayer').empty().append( $(data).find('.battle_history_singleplayer').children() );
  });
}

//function for checking if game is draw
function isDrawSingleplayer(){
	if(n == 9){
	  if((!isTrue(win1, player_fields))&&(!isTrue(win2, player_fields))&&(!isTrue(win3, player_fields))&&(!isTrue(win4, player_fields))&&(!isTrue(win5, player_fields))&&(!isTrue(win6, player_fields))&&(!isTrue(win7, player_fields))&&(!isTrue(win8, player_fields))&&(!isTrue(win1, cpu_fields))&&(!isTrue(win2, cpu_fields))&&(!isTrue(win3, cpu_fields))&&(!isTrue(win4, cpu_fields))&&(!isTrue(win5, cpu_fields))&&(!isTrue(win6, cpu_fields))&&(!isTrue(win7, cpu_fields))&&(!isTrue(win8, cpu_fields))){
	      stopTimer();
	      $(".draw").css("display", "inline");
	      $(".winner_for_submit").val("Draw game");
	      $(".singleplayer_form").submit();
	      refreshBattleHistorySingleplayer();
	      $(".revenge_button_singleplayer").css("display", "inline");
	  }
	}
}

//function for checking win for player X 
function isWinPlayer(){
	if((isTrue(win1, player_fields))||(isTrue(win2, player_fields))||(isTrue(win3, player_fields))||(isTrue(win4, player_fields))||(isTrue(win5, player_fields))||(isTrue(win6, player_fields))||(isTrue(win7, player_fields))||(isTrue(win8, player_fields))){
	     setTimeout(function(){
			$(".winner").css("display", "inline");
			var x = $(".player").val();
			$(".who").html(x);
			$(".winner_for_submit").val(x);
			$(".singleplayer_form").submit();
			refreshBattleHistorySingleplayer();
			$(".revenge_button_singleplayer").css("display", "inline");
		 }, 10);
		for(var i=0; i<=9; i++){
			$(".square_" + i + "s").attr("onclick", "false");
		}
		stopTimer();
	}
}

//function for checking win for CPU
function isWinCPU(){
	if((isTrue(win1, cpu_fields))||(isTrue(win2, cpu_fields))||(isTrue(win3, cpu_fields))||(isTrue(win4, cpu_fields))||(isTrue(win5, cpu_fields))||(isTrue(win6, cpu_fields))||(isTrue(win7, cpu_fields))||(isTrue(win8, cpu_fields))){
	        setTimeout(function(){
			    $(".winner").css("display", "inline");
			    var o = $(".cpu").val();
			    $(".who").html(o);
			    $(".winner_for_submit").val(o);
				$(".singleplayer_form").submit();
				refreshBattleHistorySingleplayer();
				$(".revenge_button_singleplayer").css("display", "inline");
			}, 10);
			for(var i=0; i<=9; i++){
				$(".square_" + i + "s").attr("onclick", "false");
			}
			stopTimer();
	     }
}


//ajax function for refresh game table for single mode
function refreshGameTableSingle(){
	$.get('/x-o-game', function(data){ 
      $('.game_table_single').empty().append( $(data).find('.game_table_single').children() );
  	});
}

function revengeSingleplayer(){
	refreshGameTableSingle();
	n = 0;
	player_fields = [];
	cpu_fields = [];
	$('.who_start_game').html("");
	$('.time').html("");
	$('.timer').html("");
		$('.game_table_single').one('click',function(){
		timer_for_new_game();
		});
	$(".revenge_button_singleplayer").css("display", "none");
	 setTimeout( function(){
        whoPlayNextSingleplayer();
    },1000);
}

//player start first against cpu
function playerStartFirst(){
		turn_helper = player_1_pic;
		turn = player_1_pic;
		$('.who_start_game').html("Player X");
}

//function for chossing who play next, every game other player play first
function whoPlayNextSingleplayer(){
	if(turn_helper == player_1_pic){
		turn_helper = player_2_pic;
		$('.who_start_game').html("Player O");
		cpuPlay();
	}
	else{
		turn = player_1_pic;
		turn_helper = player_1_pic;
		$('.who_start_game').html("Player X");
	}
}

//checking if input x is empty, after that checking if input o is empty, end if they not game table show
//and game choose who start first
$(document).ready(function(){
    $('.player').blur(function(){
        if(!$(this).val()){
            $(this).addClass("alert-danger");
        } else{
        	$(".game_table_single").css("display", "block");
            $(this).removeClass("alert-danger");
            $(".player").prop("readonly", true);
            $(".hidden_text").css("display", "block");
            playerStartFirst();
        }
    });
});

//which player click which field(if player 1 click field 1, field 1 will be added in player 1 array)
var player_fields = [];
var cpu_fields = [];

//function for computer turn
function cpuPlay(){
	//first move if cpu play first
	if(n == 0){
		var click_field = 1;
	}
	//second move if cpu play first
	else if((n == 2) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(5, player_fields) == -1)){
		var click_field = 5;
	}
	else if((n == 2) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(9, player_fields) == -1)){
		var click_field = 9;
	}
	//winner combinations
	else if((n >= 4) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(2, cpu_fields) !== -1) && (jQuery.inArray(3, player_fields) == -1)){
		var click_field = 3;
	}
	else if((n >= 4) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(3, cpu_fields) !== -1) && (jQuery.inArray(2, player_fields) == -1)){
		var click_field = 2;
	}
	else if((n >= 4) && (jQuery.inArray(2, cpu_fields) !== -1) && (jQuery.inArray(3, cpu_fields) !== -1) && (jQuery.inArray(1, player_fields) == -1)){
		var click_field = 1;
	}
	else if((n >= 4) && (jQuery.inArray(4, cpu_fields) !== -1) && (jQuery.inArray(5, cpu_fields) !== -1) && (jQuery.inArray(6, player_fields) == -1)){
		var click_field = 6;
	}
	else if((n >= 4) && (jQuery.inArray(4, cpu_fields) !== -1) && (jQuery.inArray(6, cpu_fields) !== -1) && (jQuery.inArray(5, player_fields) == -1)){
		var click_field = 5;
	}
	else if((n >= 4) && (jQuery.inArray(5, cpu_fields) !== -1) && (jQuery.inArray(6, cpu_fields) !== -1) && (jQuery.inArray(4, player_fields) == -1)){
		var click_field = 4;
	}
	else if((n >= 4) && (jQuery.inArray(7, cpu_fields) !== -1) && (jQuery.inArray(8, cpu_fields) !== -1) && (jQuery.inArray(9, player_fields) == -1)){
		var click_field = 9;
	}
	else if((n >= 4) && (jQuery.inArray(7, cpu_fields) !== -1) && (jQuery.inArray(9, cpu_fields) !== -1) && (jQuery.inArray(8, player_fields) == -1)){
		var click_field = 8;
	}
	else if((n >= 4) && (jQuery.inArray(8, cpu_fields) !== -1) && (jQuery.inArray(9, cpu_fields) !== -1) && (jQuery.inArray(7, player_fields) == -1)){
		var click_field = 7;
	}
	else if((n >= 4) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(4, cpu_fields) !== -1) && (jQuery.inArray(7, player_fields) == -1)){
		var click_field = 7;
	}
	else if((n >= 4) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(7, cpu_fields) !== -1) && (jQuery.inArray(4, player_fields) == -1)){
		var click_field = 4;
	}
	else if((n >= 4) && (jQuery.inArray(4, cpu_fields) !== -1) && (jQuery.inArray(7, cpu_fields) !== -1) && (jQuery.inArray(1, player_fields) == -1)){
		var click_field = 1;
	}
	else if((n >= 4) && (jQuery.inArray(2, cpu_fields) !== -1) && (jQuery.inArray(5, cpu_fields) !== -1) && (jQuery.inArray(8, player_fields) == -1)){
		var click_field = 8;
	}
	else if((n >= 4) && (jQuery.inArray(2, cpu_fields) !== -1) && (jQuery.inArray(8, cpu_fields) !== -1) && (jQuery.inArray(5, player_fields) == -1)){
		var click_field = 5;
	}
	else if((n >= 4) && (jQuery.inArray(5, cpu_fields) !== -1) && (jQuery.inArray(8, cpu_fields) !== -1) && (jQuery.inArray(2, player_fields) == -1)){
		var click_field = 2;
	}
	else if((n >= 4) && (jQuery.inArray(3, cpu_fields) !== -1) && (jQuery.inArray(6, cpu_fields) !== -1) && (jQuery.inArray(9, player_fields) == -1)){
		var click_field = 9;
	}
	else if((n >= 4) && (jQuery.inArray(3, cpu_fields) !== -1) && (jQuery.inArray(9, cpu_fields) !== -1) && (jQuery.inArray(6, player_fields) == -1)){
		var click_field = 6;
	}
	else if((n >= 4) && (jQuery.inArray(6, cpu_fields) !== -1) && (jQuery.inArray(9, cpu_fields) !== -1) && (jQuery.inArray(3, player_fields) == -1)){
		var click_field = 3;
	}
	else if((n >= 4) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(9, cpu_fields) !== -1) && (jQuery.inArray(5, player_fields) == -1)){
		var click_field = 5;
	}
	else if((n >= 4) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(5, cpu_fields) !== -1) && (jQuery.inArray(9, player_fields) == -1)){
		var click_field = 9;
	}
	else if((n >= 4) && (jQuery.inArray(5, cpu_fields) !== -1) && (jQuery.inArray(9, cpu_fields) !== -1) && (jQuery.inArray(1, player_fields) == -1)){
		var click_field = 1;
	}
	else if((n >= 4) && (jQuery.inArray(3, cpu_fields) !== -1) && (jQuery.inArray(7, cpu_fields) !== -1) && (jQuery.inArray(5, player_fields) == -1)){
		var click_field = 5;
	}
	else if((n >= 4) && (jQuery.inArray(3, cpu_fields) !== -1) && (jQuery.inArray(5, cpu_fields) !== -1) && (jQuery.inArray(7, player_fields) == -1)){
		var click_field = 7;
	}
	else if((n >= 4) && (jQuery.inArray(5, cpu_fields) !== -1) && (jQuery.inArray(7, cpu_fields) !== -1) && (jQuery.inArray(3, player_fields) == -1)){
		var click_field = 3;
	}
	//first move if cpu play second
	else if((n == 1) && (jQuery.inArray(5, player_fields) == -1)){
		var click_field = 5;
	}
	else if((n == 1) && (jQuery.inArray(5, player_fields) !== -1)){
		var click_field = 1;
	}
	//some attacks if real player is noob
	else if((n == 4) && (jQuery.inArray(4, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(7, cpu_fields) !== -1)){
		var click_field = 3;
	}
	else if((n == 4) && (jQuery.inArray(4, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(5, cpu_fields) !== -1)){
		var click_field = 3;
	}
	else if((n == 4) && (jQuery.inArray(2, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(1, cpu_fields) !== -1) && (jQuery.inArray(5, cpu_fields) !== -1)){
		var click_field = 7;
	}
	//other moves
	else if((n >= 3) && (jQuery.inArray(3, player_fields) !== -1) && (jQuery.inArray(5, player_fields) !== -1) && (jQuery.inArray(7, player_fields) == -1) && (jQuery.inArray(7, cpu_fields) == -1)){
		var click_field = 7;
	}
	else if((n >= 3) && (jQuery.inArray(5, player_fields) !== -1) && (jQuery.inArray(7, player_fields) !== -1) && (jQuery.inArray(3, player_fields) == -1) && (jQuery.inArray(3, cpu_fields) == -1)){
		var click_field = 3;
	}
	else if((n >= 3) && (jQuery.inArray(4, player_fields) !== -1) && (jQuery.inArray(5, player_fields) !== -1) && (jQuery.inArray(6, player_fields) == -1) && (jQuery.inArray(6, cpu_fields) == -1)){
		var click_field = 6;
	}
	else if((n >= 3) && (jQuery.inArray(5, player_fields) !== -1) && (jQuery.inArray(6, player_fields) !== -1) && (jQuery.inArray(4, player_fields) == -1) && (jQuery.inArray(4, cpu_fields) == -1)){
		var click_field = 4;
	}
	else if((n >= 3) && (jQuery.inArray(2, player_fields) !== -1) && (jQuery.inArray(5, player_fields) !== -1) && (jQuery.inArray(8, player_fields) == -1) && (jQuery.inArray(8, cpu_fields) == -1)){
		var click_field = 8;
	}
	else if((n >= 3) && (jQuery.inArray(5, player_fields) !== -1) && (jQuery.inArray(8, player_fields) !== -1) && (jQuery.inArray(2, player_fields) == -1) && (jQuery.inArray(2, cpu_fields) == -1)){
		var click_field = 2;
	}
	else if((n >= 3) && (jQuery.inArray(1, player_fields) !== -1) && (jQuery.inArray(2, player_fields) !== -1) && (jQuery.inArray(3, player_fields) == -1) && (jQuery.inArray(3, cpu_fields) == -1)){
		var click_field = 3;
	}
	else if((n >= 3) && (jQuery.inArray(1, player_fields) !== -1) && (jQuery.inArray(3, player_fields) !== -1) && (jQuery.inArray(2, player_fields) == -1) && (jQuery.inArray(2, cpu_fields) == -1)){
		var click_field = 2;
	}
	else if((n >= 3) && (jQuery.inArray(2, player_fields) !== -1) && (jQuery.inArray(3, player_fields) !== -1) && (jQuery.inArray(1, player_fields) == -1) && (jQuery.inArray(1, cpu_fields) == -1)){
		var click_field = 1;
	}
	else if((n >= 3) && (jQuery.inArray(1, player_fields) !== -1) && (jQuery.inArray(4, player_fields) !== -1) && (jQuery.inArray(7, player_fields) == -1) && (jQuery.inArray(7, cpu_fields) == -1)){
		var click_field = 7;
	}
	else if((n >= 3) && (jQuery.inArray(1, player_fields) !== -1) && (jQuery.inArray(7, player_fields) !== -1) && (jQuery.inArray(4, player_fields) == -1) && (jQuery.inArray(4, cpu_fields) == -1)){
		var click_field = 4;
	}
	else if((n >= 3) && (jQuery.inArray(4, player_fields) !== -1) && (jQuery.inArray(7, player_fields) !== -1) && (jQuery.inArray(1, player_fields) == -1) && (jQuery.inArray(1, cpu_fields) == -1)){
		var click_field = 1;
	}
	else if((n >= 3) && (jQuery.inArray(3, player_fields) !== -1) && (jQuery.inArray(6, player_fields) !== -1) && (jQuery.inArray(9, player_fields) == -1) && (jQuery.inArray(9, cpu_fields) == -1)){
		var click_field = 9;
	}
	else if((n >= 3) && (jQuery.inArray(3, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(6, player_fields) == -1) && (jQuery.inArray(6, cpu_fields) == -1)){
		var click_field = 6;
	}
	else if((n >= 3) && (jQuery.inArray(6, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(3, player_fields) == -1) && (jQuery.inArray(3, cpu_fields) == -1)){
		var click_field = 3;
	}
	else if((n >= 3) && (jQuery.inArray(7, player_fields) !== -1) && (jQuery.inArray(8, player_fields) !== -1) && (jQuery.inArray(9, player_fields) == -1) && (jQuery.inArray(9, cpu_fields) == -1)){
		var click_field = 9;
	}
	else if((n >= 3) && (jQuery.inArray(7, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(8, player_fields) == -1) && (jQuery.inArray(8, cpu_fields) == -1)){
		var click_field = 8;
	}
	else if((n >= 3) && (jQuery.inArray(8, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(7, player_fields) == -1) && (jQuery.inArray(7, cpu_fields) == -1)){
		var click_field = 7;
	}
	else if((n >= 3) && (jQuery.inArray(1, player_fields) !== -1) && (jQuery.inArray(6, player_fields) !== -1) && (jQuery.inArray(3, player_fields) == -1) && (jQuery.inArray(3, cpu_fields) == -1)){
		var click_field = 3;
	}
	else if((n >= 3) && (jQuery.inArray(1, player_fields) !== -1) && (jQuery.inArray(8, player_fields) !== -1) && (jQuery.inArray(4, player_fields) == -1) && (jQuery.inArray(4, cpu_fields) == -1)){
		var click_field = 4;
	}
	else if((n >= 3) && (jQuery.inArray(2, player_fields) !== -1) && (jQuery.inArray(7, player_fields) !== -1) && (jQuery.inArray(1, player_fields) == -1) && (jQuery.inArray(1, cpu_fields) == -1)){
		var click_field = 1;
	}
	else if((n >= 3) && (jQuery.inArray(2, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(3, player_fields) == -1) && (jQuery.inArray(3, cpu_fields) == -1)){
		var click_field = 3;
	}
	else if((n >= 3) && (jQuery.inArray(3, player_fields) !== -1) && (jQuery.inArray(4, player_fields) !== -1) && (jQuery.inArray(1, player_fields) == -1) && (jQuery.inArray(1, cpu_fields) == -1)){
		var click_field = 1;
	}
	else if((n >= 3) && (jQuery.inArray(3, player_fields) !== -1) && (jQuery.inArray(8, player_fields) !== -1) && (jQuery.inArray(6, player_fields) == -1) && (jQuery.inArray(6, cpu_fields) == -1)){
		var click_field = 6;
	}
	else if((n >= 3) && (jQuery.inArray(4, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(7, player_fields) == -1) && (jQuery.inArray(7, cpu_fields) == -1)){
		var click_field = 7;
	}
	else if((n >= 3) && (jQuery.inArray(6, player_fields) !== -1) && (jQuery.inArray(7, player_fields) !== -1) && (jQuery.inArray(9, player_fields) == -1) && (jQuery.inArray(9, cpu_fields) == -1)){
		var click_field = 9;
	}
	else if((n >= 3) && (jQuery.inArray(6, player_fields) !== -1) && (jQuery.inArray(8, player_fields) !== -1) && (jQuery.inArray(9, player_fields) == -1) && (jQuery.inArray(9, cpu_fields) == -1)){
		var click_field = 9;
	}
	else if((n >= 3) && (jQuery.inArray(4, player_fields) !== -1) && (jQuery.inArray(8, player_fields) !== -1) && (jQuery.inArray(7, player_fields) == -1) && (jQuery.inArray(7, cpu_fields) == -1)){
		var click_field = 7;
	}
	else if((n >= 3) && (jQuery.inArray(2, player_fields) !== -1) && (jQuery.inArray(6, player_fields) !== -1) && (jQuery.inArray(3, player_fields) == -1) && (jQuery.inArray(3, cpu_fields) == -1)){
		var click_field = 3;
	}
	else if((n >= 3) && (jQuery.inArray(2, player_fields) !== -1) && (jQuery.inArray(4, player_fields) !== -1) && (jQuery.inArray(1, player_fields) == -1) && (jQuery.inArray(1, cpu_fields) == -1)){
		var click_field = 1;
	}
	else if((n >= 3) && (jQuery.inArray(5, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(3, player_fields) == -1) && (jQuery.inArray(3, cpu_fields) == -1)){
		var click_field = 3;
	}
	else if((n >= 3) && (jQuery.inArray(1, player_fields) !== -1) && (jQuery.inArray(5, player_fields) !== -1) && (jQuery.inArray(9, player_fields) == -1) && (jQuery.inArray(9, cpu_fields) == -1)){
		var click_field = 9;
	}
	else if((n >= 3) && (jQuery.inArray(1, player_fields) !== -1) && (jQuery.inArray(9, player_fields) !== -1) && (jQuery.inArray(6, player_fields) == -1) && (jQuery.inArray(6, cpu_fields) == -1)){
		var click_field = 6;
	}
	else if((n >= 3) && (jQuery.inArray(3, player_fields) !== -1) && (jQuery.inArray(7, player_fields) !== -1) && (jQuery.inArray(4, player_fields) == -1) && (jQuery.inArray(4, cpu_fields) == -1)){
		var click_field = 4;
	}
	else if((n >= 3) && (jQuery.inArray(2, player_fields) !== -1) && (jQuery.inArray(8, player_fields) !== -1) && (jQuery.inArray(4, player_fields) == -1) && (jQuery.inArray(4, cpu_fields) == -1)){
		var click_field = 4;
	}
	else if((n >= 3) && (jQuery.inArray(4, player_fields) !== -1) && (jQuery.inArray(6, player_fields) !== -1) && (jQuery.inArray(2, player_fields) == -1) && (jQuery.inArray(2, cpu_fields) == -1)){
		var click_field = 2;
	}
	//lapse combination (if somewhere cpu dont know how to move)
	//<9 because after every click function cpu play, and if we dont have this "if" we will have infinitive loop
	//because all numbers are taken(if player start first) and this loop cant find free number
	else if(n < 9){
		var random_value = Math.floor((Math.random() * 9) + 1);
		while (($.inArray(random_value, player_fields) != -1) || ($.inArray(random_value, cpu_fields) != -1)){
	        random_value = Math.floor((Math.random() * 9) + 1);
	        if(($.inArray(random_value, player_fields) == -1) && ($.inArray(random_value, cpu_fields) == -1)){
	        var click_field = random_value;
	         break;
	        }
    	}
	}

	n++;
	$(".img" + click_field).attr("src", player_2_pic).fadeIn('fast').css('width', '11vh');	
	turn = player_1_pic;
    $(".square_" + click_field + "s").attr("onclick", "false");
	cpu_fields.push(click_field);
	  	isWinCPU();
	    isDrawSingleplayer();
}


//9 fields, 9 click functions
function clickFunction1s() {
if(turn == player_1_pic){
	n++;
	  $(".img1").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_1s").attr("onclick", "false");
	  player_fields.push(1);
		    isWinPlayer();
	        isDrawSingleplayer();
	        cpuPlay();
} 
}
function clickFunction2s() {
if(turn == player_1_pic){
	n++;
	  $(".img2").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_2s").attr("onclick", "false");
	  player_fields.push(2);
	        isWinPlayer();
	        isDrawSingleplayer();
	        cpuPlay();
} 
}

function clickFunction3s() {
if(turn == player_1_pic){
	n++;
	  $(".img3").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_3s").attr("onclick", "false");
	  player_fields.push(3);
	        isWinPlayer();
	        isDrawSingleplayer();
	        cpuPlay();
} 
}

function clickFunction4s() {
if(turn == player_1_pic){
	n++;
	  $(".img4").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_4s").attr("onclick", "false");
	  player_fields.push(4);
	        isWinPlayer();
	        isDrawSingleplayer();
	        cpuPlay();
} 
}

function clickFunction5s() {
if(turn == player_1_pic){
	n++;
	  $(".img5").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_5s").attr("onclick", "false");
	  player_fields.push(5);
	        isWinPlayer();
	        isDrawSingleplayer();
	        cpuPlay();
} 
}

function clickFunction6s() {
if(turn == player_1_pic){
	n++;
	  $(".img6").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_6s").attr("onclick", "false");
	  player_fields.push(6);
	        isWinPlayer();
	        isDrawSingleplayer();
	        cpuPlay();
} 
}

function clickFunction7s() {
if(turn == player_1_pic){
	n++;
	  $(".img7").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_7s").attr("onclick", "false");
	  player_fields.push(7);
	        isWinPlayer();
	        isDrawSingleplayer();
	        cpuPlay();
} 
}

function clickFunction8s() {
if(turn == player_1_pic){
	n++;
	  $(".img8").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_8s").attr("onclick", "false");
	  player_fields.push(8);
	        isWinPlayer();
	        isDrawSingleplayer();
	        cpuPlay();
} 
}

function clickFunction9s() {
if(turn == player_1_pic){
	n++;
	  $(".img9").attr("src", player_1_pic).fadeIn('fast').css('width', '11vh');
	  turn = player_2_pic;
	  $(".square_9s").attr("onclick", "false");
	  player_fields.push(9);
	        isWinPlayer();
	        isDrawSingleplayer();
	        cpuPlay();
} 
}

//on click on table timer start
$('.game_table_single').one('click',function(){
	timer_for_new_game();
});

</script>




</body>
</html>
